#ifndef H5Z_ZFP_H
#define H5Z_ZFP_H

#include "H5Zzfp_lib.h"
#include "H5Zzfp_plugin.h"
#include "H5Zzfp_props.h"

#endif
